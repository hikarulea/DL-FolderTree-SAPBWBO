# requirement name




[TOC]

## Requirement & Solution

### 背景/现状



### 需求

相关文档

### 分析

#### 需求概要



#### 现有逻辑(数据来源)

##### XX 部分

#### 维度来源/逻辑

#### 指标来源/逻辑

##### A

#### 指标公式逻辑

##### A

### 方案

#### 概览



#### 历史数据



### 潜在问题




## Development

### DataSource

#### 新增



### InfoObject(Master Data)



### DSO

#### 原有模型



#### 抽取层



#### 合并层



### InfoCube



### Multiprovider



### Transformation(仅重要)



### Query



### Process Chain





## Reference

* 

## Changelog

* 20YYMMDD: New