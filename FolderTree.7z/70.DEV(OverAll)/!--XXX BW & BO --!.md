
## Format String

###  BO

#### Promotion Job
Naming Rule
~~~ String_Template

~~~

### BW

#### BW Process Chain

#### Delete InfoProvider Data
~~~ String_Template

~~~


#### Delete Index
~~~ String_Template

~~~

#### Delete PSA
~~~ String_Template

~~~


## Code Templates

~~~ ABAP
*-- Old code before 20170712 --> Start
*-- Old code before 20170712 --< End
~~~

### Field Routine

#### Convert Fiscal Period to Calmonth
~~~ ABAP

~~~

### DTP Filter Routine

#### CALMONTH，有2个月份备选
DTP Filter Routine1, 
~~~ ABAP

~~~

#### CALDAY(BT)
DTP Filter Routine2, 
~~~ ABAP

~~~

#### CALDAY
DTP Filter Routine3
~~~ ABAP

~~~

### InfoPackage File Name Routine
~~~ ABAP

~~~

### Transformation

#### Self Data Remove

~~~ ABAP

~~~

~~~ ABAP

~~~

