# XXX项目记录
## 本周任务

## 待办
* 

## 待检查
* 

## 待传输
* 

## 待解决问题


## 待观察(潜在的)问题
* 

## 备忘录
* 

## 需方案
* 


## 备注
* AAA:
  * aaa
  * bbb
* BBB
* CCC
  

##### XX 相关
* 

## 常用信息

### TCode
| TCode | Comments |
| ----- | -------- |
|       |          |
|       |          |

### BW Table
```
RSSTATMANPART
```
### BW Process Chain
```
BW FM
RSPC_CHAIN_ACTIVATE_REMOTE
```
### BO Schedule Related
BO 发送邮件时使用的 From 地址
```

```

### Account Information
SIT - Test User
```

```

UAT - Test User
```

```
## 常用 InfoObject 描述

### XXX - YYY